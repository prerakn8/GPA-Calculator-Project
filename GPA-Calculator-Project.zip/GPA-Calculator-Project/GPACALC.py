﻿"""
Prerak Naik & Saharsh Munagani
GPA Calculator for FBLA
Python
4/8/24
"""

"""
Some basic things to know:

All guis use CustomTkinter for their guis
Labels, Buttons, Comboboxes, Frames(which hold the other gui components) are known as what they do, so comments have not been added there
Comments only explain custom-made classes, modules, but do not explain overall guis and functions
"""
import pyautogui #This module allows for the mouse position on screen to be shown as a variable.
import customtkinter #Imports a gui library which is better than normal tkinter and allows more customization and modern user interfaces
from tkinter import messagebox #Imports messagebox, which will warn the user based on the prompt and text
from PIL import Image #Imports an image library that allows images to be displayed on the buttons in the sidebar on the left of the screen

customtkinter.deactivate_automatic_dpi_awareness() #Changes default scaling
        
#Main window

app = customtkinter.CTk()
app.title("Gpa Calculator")
app.geometry("500x500")

#Classes

class gpacalcclassframe(): #This frame is for the courses that are visible in the gpa calculator
    def terminatecourseframe(self): 
        global gradeslist
        global coursetypelist
        global gradepointlistvar
        self.course1framecoursegrade.configure(text = "") 
        self.course1framecoursetype.configure(text = "")
        gradepointlistvar -= 1
        self.course1frame.grid_forget()
        self.visible = False

    def __init__(self, master, rowpos, visible):
        
        self.visible = visible
        
        self.master = master
        
        self.rowpos = rowpos
                
        self.course1frame = customtkinter.CTkFrame(self.master, fg_color = "#303030", width = 570, height = 60, corner_radius = 20)
        
        self.course1frame.bind("<Motion>", on_leave)

        self.course1frameid = customtkinter.CTkLabel(self.course1frame, text = self.rowpos, fg_color = "#303030",
                                                text_color = "gray", font = ("Dubai", 18), width = 1, height = 30)
        self.course1frameid.place(x = 20, y = 15)

        self.course1framecoursename = customtkinter.CTkLabel(self.course1frame, text = "", fg_color = "#303030",
                                                text_color = "white", font = ("Dubai", 18), width = 1, height = 30)
        self.course1framecoursename.place(x = 90, y = 15)

        self.course1framecoursegrade = customtkinter.CTkLabel(self.course1frame, text = "", fg_color = "#303030",
                                                text_color = "white", font = ("Dubai", 18), width = 1, height = 30)
        self.course1framecoursegrade.place(x = 255, y = 15)

        self.course1framecoursetype = customtkinter.CTkLabel(self.course1frame, text = "", fg_color = "#303030", 
                                                text_color = "white", font = ("Dubai", 18), width = 1, height = 30)
        self.course1framecoursetype.place(x = 385, y = 15)

        self.course1framecoursedelete = customtkinter.CTkButton(self.course1frame, width = 35, height = 20, corner_radius = 20,
                                                   fg_color = "#303030", text_color = "white", font = ("Dubai", 18), 
                                                   text = "🗑", hover_color = "#303030", command = self.terminatecourseframe)
        self.course1framecoursedelete.place(x = 510, y = 13)
        self.course1framecoursedelete.bind("<Motion>", lambda event: on_enter(event, "Removes Course From List"))

    def setpos(self, x, y):
        self.course1frame.grid(column = x, row = y, pady = 10)




class numbutton(): #The button for the calculator
    def setposition(self, column, row):
        self.guinumcalcbutton.grid(column = column, row = row, padx = 10, pady = 10)
        
    def __init__(self, numtoinput):
        
        self.numtoinput = numtoinput 
        
        self.guinumcalcbutton = customtkinter.CTkButton(guinumcalcbuttonframe, corner_radius = 10, width = 100, height = 100,
                                                   fg_color = "#343434", text_color = "white", font = ("Dubai", 30), 
                                                   text = str(self.numtoinput), hover_color = "#343434", 
                                                   command = lambda: guinumcalcframeentry.insert(len(guinumcalcframeentry.get()), str(numtoinput)))

#Functions

"""Any function with 'open' in it opens a gui and hides the others"""

def opengpacalcfunc():
    startupframe.place_forget() 
    guicalcframe.place(x = 0, y = 0)
    guinumcalcframe.place_forget()
    Iconholderframe.place(x = 0, y = 0) 
    Iconholderframeshow.place(x = 10, y = 0)  

def opennumcalc(): 
    global calcenabledval
    if calcenabledval == False:
        guinumcalcframe.place(x = 200, y = 100) 
        calcenabledval = True
    elif calcenabledval == True:
        guinumcalcframe.place_forget()
        calcenabledval = False
    

    Iconholderframe.place(x = 0, y = 0)
    Iconholderframeshow.place(x = 10, y = 0)
    
def addcourse(): #Adds a frame to the larger frame in the gpa calculator gui
    global gradepointlistvar
    
    if gpanameentry.get().isspace() == True:
        messagebox.showerror("Error", "Please enter a course name")
    elif gpanameentry.get() == "":
        messagebox.showerror("Error", "Please enter a course name")
    else:
        if courseframethingnew1.visible == False: 
            courseframethingnew1.course1frame.grid(column = 0, row = 0, pady = 10) 
            courseframethingnew1.course1framecoursename.configure(text = str(gpanameentry.get())) 
            courseframethingnew1.course1framecoursegrade.configure(text = str(gpanumentry.get())) 
            courseframethingnew1.course1framecoursetype.configure(text = str(gpacombobox.get()))
            courseframethingnew1.visible = True 
        
        elif courseframethingnew2.visible == False:
            courseframethingnew2.course1frame.grid(column = 0, row = 1, pady = 10)
            courseframethingnew2.course1framecoursename.configure(text = str(gpanameentry.get()))
            courseframethingnew2.course1framecoursegrade.configure(text = str(gpanumentry.get()))
            courseframethingnew2.course1framecoursetype.configure(text = str(gpacombobox.get()))
            courseframethingnew2.visible = True
        
        elif courseframethingnew3.visible == False:
            courseframethingnew3.course1frame.grid(column = 0, row = 2, pady = 10)
            courseframethingnew3.course1framecoursename.configure(text = str(gpanameentry.get()))
            courseframethingnew3.course1framecoursegrade.configure(text = str(gpanumentry.get()))
            courseframethingnew3.course1framecoursetype.configure(text = str(gpacombobox.get()))
            courseframethingnew3.visible = True
        
        elif courseframethingnew4.visible == False:
            courseframethingnew4.course1frame.grid(column = 0, row = 3, pady = 10)
            courseframethingnew4.course1framecoursename.configure(text = str(gpanameentry.get()))
            courseframethingnew4.course1framecoursegrade.configure(text = str(gpanumentry.get()))
            courseframethingnew4.course1framecoursetype.configure(text = str(gpacombobox.get()))
            courseframethingnew4.visible = True
        
        elif courseframethingnew5.visible == False:
            courseframethingnew5.course1frame.grid(column = 0, row = 4, pady = 10)
            courseframethingnew5.course1framecoursename.configure(text = str(gpanameentry.get()))
            courseframethingnew5.course1framecoursegrade.configure(text = str(gpanumentry.get()))
            courseframethingnew5.course1framecoursetype.configure(text = str(gpacombobox.get()))
            courseframethingnew5.visible = True
        
        elif courseframethingnew6.visible == False:
            courseframethingnew6.course1frame.grid(column = 0, row = 5, pady = 10)
            courseframethingnew6.course1framecoursename.configure(text = str(gpanameentry.get()))
            courseframethingnew6.course1framecoursegrade.configure(text = str(gpanumentry.get()))
            courseframethingnew6.course1framecoursetype.configure(text = str(gpacombobox.get()))
            courseframethingnew6.visible = True
        
        elif courseframethingnew7.visible == False:
            courseframethingnew7.course1frame.grid(column = 0, row = 6, pady = 10)
            courseframethingnew7.course1framecoursename.configure(text = str(gpanameentry.get()))
            courseframethingnew7.course1framecoursegrade.configure(text = str(gpanumentry.get()))
            courseframethingnew7.course1framecoursetype.configure(text = str(gpacombobox.get()))
            courseframethingnew7.visible = True
        gradepointlistvar += 1 

def clrallcourses():
    global gradeslist
    global coursetypelist
    global gradespointlist
    global unweightedvar
    global weightedvar
    global gradepointlistvar
    asktoclear = messagebox.askyesno("Warning", "Do you want to clear all courses?")
    if asktoclear == True:
        courseframethingnew1.terminatecourseframe()
        courseframethingnew2.terminatecourseframe()
        courseframethingnew3.terminatecourseframe()
        courseframethingnew4.terminatecourseframe()
        courseframethingnew5.terminatecourseframe()
        courseframethingnew6.terminatecourseframe()
        courseframethingnew7.terminatecourseframe()
        gradeslist.clear()
        coursetypelist.clear()
        gradespointlist.clear()
        gradepointlistvar = 0
        unweightedvar = 0
        weightedvar = 0
        gpadisplaylabel.configure(text = str(0.0))
    
def calculatefunc():
    global gradeslist
    global coursetypelist
    global gradespointlist
    global unweightedvar
    global weightedvar
    global gradepointlistvar
    
    if gpanameentry.get().isspace() == True:
        messagebox.showerror("Error", "Please enter a course name.")
    elif gpanameentry.get() == "":
        messagebox.showerror("Error", "Please enter a course name.")
    else:
        gradeslist.clear()
        coursetypelist.clear()
        gradespointlist.clear()

        gradeslist.append(courseframethingnew1.course1framecoursegrade.cget("text"))
        gradeslist.append(courseframethingnew2.course1framecoursegrade.cget("text"))
        gradeslist.append(courseframethingnew3.course1framecoursegrade.cget("text"))
        gradeslist.append(courseframethingnew4.course1framecoursegrade.cget("text"))
        gradeslist.append(courseframethingnew5.course1framecoursegrade.cget("text"))
        gradeslist.append(courseframethingnew6.course1framecoursegrade.cget("text"))
        gradeslist.append(courseframethingnew7.course1framecoursegrade.cget("text"))
    

        coursetypelist.append(courseframethingnew1.course1framecoursetype.cget("text"))
        coursetypelist.append(courseframethingnew2.course1framecoursetype.cget("text"))
        coursetypelist.append(courseframethingnew3.course1framecoursetype.cget("text"))
        coursetypelist.append(courseframethingnew4.course1framecoursetype.cget("text"))
        coursetypelist.append(courseframethingnew5.course1framecoursetype.cget("text"))
        coursetypelist.append(courseframethingnew6.course1framecoursetype.cget("text"))
        coursetypelist.append(courseframethingnew7.course1framecoursetype.cget("text"))
        
        if all(not elem for elem in gradeslist):
            messagebox.showerror("Error", "Please enter a course first.")
        else:    
            for n in range(len(gradeslist)):
                if gradeslist[n] == "A":
                    gradespointlist.append(4.0)
                if gradeslist[n] == "B":
                    gradespointlist.append(3.0)
                if gradeslist[n] == "C":
                    gradespointlist.append(2.0)
                if gradeslist[n] == "D":
                    gradespointlist.append(1.0)
                if gradeslist[n] == "F":
                    gradespointlist.append(0.0)
                    
            dividedvar = sum(gradespointlist) / len(gradespointlist)
            unweightedvar = str(dividedvar)[0:4] #The unweighted gpa
    
            for i in range(gradepointlistvar):
                if coursetypelist[i] == "AP/IB":
                    gradespointlist[i] += 1
                if coursetypelist[i] == "Honors":
                    gradespointlist[i] += 0.5
    
            findividedvar = sum(gradespointlist) / len(gradespointlist)
            weightedvar = str(findividedvar)[0:4] #The weighted gpa
    
            if gpadisplayswitch.get() == "Disabled":
                gpadisplaylabel.configure(text = str(unweightedvar)) 
            elif gpadisplayswitch.get() == "Enabled":
                gpadisplaylabel.configure(text = str(weightedvar))

def showgpa(): #Shows the gui based on the value of the switch in the gpa calculator gui
    global hasbeencleared
    global unweightedvar
    global weightedvar
    if gpadisplayswitch.get() == "Disabled":
        gpadisplaylabel.configure(text = str(unweightedvar)) 
        gpadisplayswitch.configure(text = " Unweighted")
    elif gpadisplayswitch.get() == "Enabled":
        gpadisplaylabel.configure(text = str(weightedvar)) 
        gpadisplayswitch.configure(text = " Weighted")

def guinumcalcframecalculate():
    if guinumcalcframeentry.get().isalpha() == True:
        messagebox.showerror("Error", "Cannot input characters into the calculator!") 
    
    if guinumcalcframeentry.get()[-2:] == "/0":
        messagebox.showerror("Error", "Cannot divide by 0!") 
    
    if guinumcalcframeentry.get() == "":
        messagebox.showerror("Error", "Please enter a calculation!") 
        
    calculation = eval(guinumcalcframeentry.get())
    guinumcalcframeentry.delete(0,len(guinumcalcframeentry.get()))
    guinumcalcframeentry.insert(0, calculation)
    
def on_enter(event, text):
    current_mouse_position = pyautogui.position()
    tooltipnew.place(x = current_mouse_position.x, y = current_mouse_position.y)
    tooltipnew.configure(text = text)
    
def on_leave(event):
    tooltipnew.place_forget()

framemenuenabledbool = False

unweightedvar = 0

weightedvar = 0

calcenabledval = False

showpasswordvar = False

#Lists

gradeslist = []
coursetypelist = []
gradespointlist = []
gradepointlistvar = 0

#The startup menu gui

startupframe = customtkinter.CTkFrame(app, width = 1920, height = 1080, fg_color = "#242424")
startupframe.place(x = 0, y = 0)

mainmenulabel = customtkinter.CTkLabel(startupframe, text = "GPA Calculator", width = 350, height = 90, font = ("Dubai", 52,'bold'))
mainmenulabel.place(x = 785, y = 100)

mainmenudescription = customtkinter.CTkLabel(startupframe, text = "Developed by Prerak N, in partnership with Saharsh M.", width = 576,
                                             font = ("Dubai Light", 26))
mainmenudescription.place(x = 672, y = 200)

mainmenubutton = customtkinter.CTkButton(startupframe, text = "Start Calculating", width = 260, height = 60, text_color = "white", font = ("Dubai", 30), corner_radius = 1000,
                                        bg_color = "transparent", fg_color = "transparent", border_color = "white", border_width = 1, command = opengpacalcfunc,
                                         hover_color = "#121212")
mainmenubutton.place(x = 830, y = 290)

#The GPA calculator gui

guicalcframe = customtkinter.CTkFrame(app, width = 1920, height = 1080, fg_color = "#242424")
guicalcframe.place_forget()
guicalcframe.bind("<Motion>", on_leave)

gpacomboboxlabel = customtkinter.CTkLabel(guicalcframe, text = "Course Type", fg_color = "transparent", 
                                                text_color = "white", font = ("Dubai", 18), width = 1, height = 30)
gpacomboboxlabel.place(x = 610, y = 750)

gpacombobox = customtkinter.CTkComboBox(guicalcframe, values=["AP/IB", "Honors", "L2", "Other"], font = ("Dubai", 16), text_color = "white", 
                                        dropdown_font = ("Dubai", 16), fg_color = "#303030", dropdown_fg_color = "#303030",
                                        button_color = "#303030", border_color = "#303030", state = "readonly")
gpacombobox.set("L2")

gpacombobox.place(x = 610, y = 785)

gpanameentrylabel = customtkinter.CTkLabel(guicalcframe, text = "Course Name", fg_color = "transparent", 
                                                text_color = "white", font = ("Dubai", 18), width = 1, height = 30)
gpanameentrylabel.place(x = 150, y = 750)

gpanameentry = customtkinter.CTkEntry(guicalcframe, font = ("Dubai", 16), text_color = "white", fg_color = "#303030", 
                                      border_color = "#303030", placeholder_text = "Name...", placeholder_text_color = "gray")
gpanameentry.place(x = 150, y = 785)

gpanumentrylabel = customtkinter.CTkLabel(guicalcframe, text = "Course Grade", fg_color = "transparent", 
                                                text_color = "white", font = ("Dubai", 18), width = 1, height = 30)
gpanumentrylabel.place(x = 380, y = 750)

gpanumentry = customtkinter.CTkComboBox(guicalcframe, values=["A", "B", "C", "D", "F"], font = ("Dubai", 16), text_color = "white", 
                                        dropdown_font = ("Dubai", 16), fg_color = "#303030", dropdown_fg_color = "#303030",
                                        button_color = "#303030", border_color = "#303030", state = "readonly")
gpanumentry.set("A")

gpanumentry.place(x = 380, y = 785)

guicalctitle = customtkinter.CTkLabel(guicalcframe, width = 5, height = 20, fg_color = "transparent", 
                                      text_color = "white", font = ("Dubai", 36, "bold"), text = "Need some help?")
guicalctitle.place(x = 1250, y = 50)

gpahelpsidelabel = customtkinter.CTkLabel(guicalcframe, fg_color = "transparent", 
                                                text_color = "white", font = ("Dubai", 20), justify = "left", anchor = "w", text = 
                                                                
"""Essentially, this easy-to-use gpa calculator allows for 
values to be inputted in the GPA calculator to return the 
unweighted and weighted GPAs. To begin, input the name of a 
course you have taken in the textbox beneath the label that 
says 'Course Name'. These next labels are found at the bottom of
the page. Next, input the grade in that specific course into the 
textbox beneath the label 'Course Grade'. Once that has been 
completed, select the type of course that the course you took 
was in the dropdown below the label that says 'Course Type'. 
This can change the weighting of the grades. All set? Now, hit 
the 'Add Course' button, which will add all of the information
you just added into the frame just above that button. We 
recommend that you add multiple courses, not just one. Once you
are satisfied with the amount of courses added to the frame,
click on the 'Calculate' button. This will show the unweighted 
and weighted GPAs of all the courses you entered in the box. If
you have entered a course on accident, click the icon that looks
like a trashcan which is on the right side of the icon. You can
delete all the courses from the frame immediately by clicking the
'Clear All' button next to the 'Add Course' button. The grading 
scale is as follows: A = 93-100, B= 86-92, C = 77-85, D = 70-76, 
F = 0-69.""")

gpahelpsidelabel.place(x = 1250, y = 120)

calculatebutton = customtkinter.CTkButton(guicalcframe, corner_radius = 100, width = 140, height = 40,
                                                   fg_color = "dodgerblue", text_color = "white", font = ("Dubai", 18), 
                                                   text = "Calculate", hover_color = "dodgerblue", command = calculatefunc)
calculatebutton.place(x = 150, y = 880)
calculatebutton.bind("<Motion>", lambda event: on_enter(event, "Calculates The GPA Based On The Courses In The Box Above"))

addnewcoursetolistbutton = customtkinter.CTkButton(guicalcframe, corner_radius = 100, width = 140, height = 40,
                                                   fg_color = "transparent", text_color = "white", font = ("Dubai", 18), 
                                                   text = "Add Course", border_color = "white", border_width = 1, 
                                                   hover_color = "#121212", command = addcourse)
addnewcoursetolistbutton.place(x = 380, y = 880)
addnewcoursetolistbutton.bind("<Motion>", lambda event: on_enter(event, "Adds New Course To The Box Above"))

clearallcoursesbutton = customtkinter.CTkButton(guicalcframe, corner_radius = 100, width = 140, height = 40,
                                                   fg_color = "transparent", text_color = "white", font = ("Dubai", 18), 
                                                   text = "Clear All", border_color = "white", border_width = 1, 
                                                   hover_color = "#121212", command = clrallcourses)
clearallcoursesbutton.place(x = 610, y = 880)
clearallcoursesbutton.bind("<Motion>", lambda event: on_enter(event, "Clears All Courses In The Box Above"))

guicalctitle = customtkinter.CTkLabel(guicalcframe, width = 5, height = 20, fg_color = "transparent", 
                                      text_color = "white", font = ("Dubai", 40, "bold"), text = "GPA Calculator")
guicalctitle.place(x = 150, y = 50)

gpadisplayswitch = customtkinter.CTkSwitch(guicalcframe, text = " Unweighted", fg_color = "#323232", button_color = "white",
                                                text_color = "white", font = ("Dubai", 22), width = 1, height = 30,
                                                progress_color = "dodgerblue", command = showgpa, offvalue = "Disabled",
                                                onvalue = "Enabled")
gpadisplayswitch.place(x = 910, y = 150)

gpadisplaylabel = customtkinter.CTkLabel(guicalcframe, text = "0.00", fg_color = "transparent", 
                                                text_color = "gray", font = ("Dubai", 22), width = 1, height = 30)
gpadisplaylabel.place(x = 970, y = 190)

allclassesframe = customtkinter.CTkFrame(guicalcframe, fg_color = "#292929", width = 600, height = 570, corner_radius = 20, 
                                         border_color = "#303030", border_width = 1)
allclassesframe.place(x = 150, y = 150)

allclassesframe.bind("<Motion>", on_leave)

actualholderclassesframe = customtkinter.CTkFrame(guicalcframe, fg_color = "#292929", width = 570, height = 550, 
                                                  corner_radius = 0) 
                                         
actualholderclassesframe.place(x = 165, y = 155)

courseframethingnew1 = gpacalcclassframe(actualholderclassesframe, "1", False)
courseframethingnew1.setpos(0,0)
courseframethingnew1.course1frame.grid_forget()

courseframethingnew2 = gpacalcclassframe(actualholderclassesframe, 2, False)
courseframethingnew2.setpos(0,1)
courseframethingnew2.course1frame.grid_forget()

courseframethingnew3 = gpacalcclassframe(actualholderclassesframe, 3, False)
courseframethingnew3.setpos(0,2)
courseframethingnew3.course1frame.grid_forget()

courseframethingnew4 = gpacalcclassframe(actualholderclassesframe, 4, False)
courseframethingnew4.setpos(0,3)
courseframethingnew4.course1frame.grid_forget()

courseframethingnew5 = gpacalcclassframe(actualholderclassesframe, 5, False)
courseframethingnew5.setpos(0,4)
courseframethingnew5.course1frame.grid_forget()

courseframethingnew6 = gpacalcclassframe(actualholderclassesframe, 6, False)
courseframethingnew6.setpos(0,5)
courseframethingnew6.course1frame.grid_forget()

courseframethingnew7 = gpacalcclassframe(actualholderclassesframe, 7, False)
courseframethingnew7.setpos(0,6)
courseframethingnew7.course1frame.grid_forget()

#Gui for the number calculator

guinumcalcframe = customtkinter.CTkFrame(app, width = 500, height = 600, fg_color = "#282828", border_color = "white", border_width = 1)
guinumcalcframe.place_forget()
guinumcalcframe.bind("<Motion>", on_leave)

guinumcalcframeentry = customtkinter.CTkEntry(guinumcalcframe, width = 480, font = ("Dubai", 26), text_color = "white", fg_color = "#303030", 
                                      height = 90, border_color = "#282828", corner_radius = 10, justify = "right")
guinumcalcframeentry.place(x = 10, y = 10)

guinumcalcbuttonframe = customtkinter.CTkFrame(guinumcalcframe, width = 580, height = 510, fg_color = "transparent")
guinumcalcbuttonframe.place(x = 10, y = 110)

guinumcalcbutton1 = numbutton(1) 
guinumcalcbutton1.setposition(0,0)

guinumcalcbutton2 = numbutton(2)
guinumcalcbutton2.setposition(1,0)

guinumcalcbutton3 = numbutton(3)
guinumcalcbutton3.setposition(2,0)

guinumcalcbutton4 = numbutton(4)
guinumcalcbutton4.setposition(0,1)

guinumcalcbutton5 = numbutton(5)
guinumcalcbutton5.setposition(1,1)

guinumcalcbutton6 = numbutton(6)
guinumcalcbutton6.setposition(2,1)

guinumcalcbutton7 = numbutton(7)
guinumcalcbutton7.setposition(0,2)

guinumcalcbutton8 = numbutton(8)
guinumcalcbutton8.setposition(1,2)

guinumcalcbutton9 = numbutton(9)
guinumcalcbutton9.setposition(2,2)

guinumcalcbutton10 = numbutton(0)
guinumcalcbutton10.setposition(0,3)

guinumcalcbutton11 = numbutton("C")
guinumcalcbutton11.guinumcalcbutton.configure(
    command = lambda: guinumcalcframeentry.delete(0,len(guinumcalcframeentry.get())))
guinumcalcbutton11.setposition(1,3)

guinumcalcbutton12 = numbutton("=")
guinumcalcbutton12.guinumcalcbutton.configure(
    command = guinumcalcframecalculate)
guinumcalcbutton12.setposition(2,3)

guinumcalcbutton13 = numbutton("+")
guinumcalcbutton13.setposition(3,0)

guinumcalcbutton14 = numbutton("-")
guinumcalcbutton14.setposition(3,1)

guinumcalcbutton15 = numbutton("*")
guinumcalcbutton15.setposition(3,2)

guinumcalcbutton16 = numbutton("/")
guinumcalcbutton16.setposition(3,3)

#Holds the side icons

Iconholderframe = customtkinter.CTkFrame(app, fg_color = "#363636", width = 100, height = 1080)
Iconholderframe.place_forget()
Iconholderframe.bind("<Motion>", on_leave)

Iconholderframeshow = customtkinter.CTkFrame(app, fg_color = "#363636", width = 80, height = 1080)
Iconholderframeshow.place_forget()
Iconholderframeshow.bind("<Motion>", on_leave)

gpacalculatoropenerbutton = customtkinter.CTkButton(Iconholderframeshow, text = "", width = 60, height = 60, hover_color = "#363636", fg_color = "transparent",
                                                command = opengpacalcfunc,
                                                image = customtkinter.CTkImage(dark_image =
                                                Image.open("CalculatorIcon.png"), size = (60,60)))
gpacalculatoropenerbutton.place(x = 2, y = 5)
gpacalculatoropenerbutton.bind("<Motion>", lambda event: on_enter(event, "Open GPA Calculator"))

calculatoropenerbutton = customtkinter.CTkButton(Iconholderframeshow, text = "", width = 60, height = 60, hover_color = "#363636", fg_color = "transparent",
                                                 command = opennumcalc,
                                                image = customtkinter.CTkImage(dark_image =
                                                Image.open("HomeIcon.png"), size = (60,60)))
calculatoropenerbutton.place(x = 2, y = 85)
calculatoropenerbutton.bind("<Motion>", lambda event: on_enter(event, "Open Number Calculator"))

#Tooltip gui

tooltipnew = customtkinter.CTkLabel(app, text_color = "white", font = ("Dubai", 18), text = "tooltip", 
                                    anchor = "center", justify = "center", fg_color = "#303030", 
                                    bg_color = "#303030", corner_radius = 8)
tooltipnew.place(x = -100, y = -100)

app.mainloop() #Loops the gui